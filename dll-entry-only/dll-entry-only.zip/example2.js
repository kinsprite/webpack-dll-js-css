export default 10;

export function myFunc() {
    import('./async-d2.css');
    import('./async-d2');
}

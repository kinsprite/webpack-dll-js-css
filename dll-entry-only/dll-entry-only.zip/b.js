// module b
export function b() {
	import('./async-d');
	return "b";
}


import "./async-d3.css";

export default function myF() {
    console.warn('abc');
}

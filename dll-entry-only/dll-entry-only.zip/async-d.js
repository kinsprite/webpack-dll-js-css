export default function myF() {
    console.warn('222');
}

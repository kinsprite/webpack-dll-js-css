// module cjs (commonjs)
exports.c = "c";
